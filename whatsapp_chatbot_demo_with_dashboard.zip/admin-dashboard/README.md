Admin Dashboard (React + Vite)

Quick start:
1. cd admin-dashboard
2. npm install
3. npm run dev

Usage:
- Toggle Mode: Live API (calls your backend) or Demo (mock data)
- Theme button toggles Light/Dark mode (persisted in localStorage)
- If using Live API, set VITE_API_URL environment variable or edit the API URL in the dashboard header
